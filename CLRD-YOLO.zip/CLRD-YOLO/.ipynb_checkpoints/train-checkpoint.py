from ultralytics import YOLO

# if __name__ == '__main__':
#     # Load a model
#     # model = YOLO("yolov8.yaml")  # build a new model from scratch
#     # model = YOLO("yolov8n.pt")  # load a pretrained model (recommended for training)
#     #
#     # # Use the model
#     #
#     # model.train(data="mycoco128.yaml", epochs=100)  # train the model
#     # metrics = model.val()  # evaluate model performance on the validation set
#     model = YOLO("/root/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8-SPPF-SimAM.yaml").train(**{'cfg': 'ultralytics/cfg/default.yaml'})

# if __name__ == '__main__':
#     model = YOLO('/root/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8s-SRFD.yaml')
#     # model.load('yolov8n.pt') # loading pretrain weight
#     model.train(data='/root/ultralytics-main/ultralytics-main/ultralytics/cfg/datasets/coco128.yaml',
#                 name='yolov8数据增强-yolov8s-SRFD-2024.9.22',
#                 ) 
    
    
    
if __name__ == '__main__':
    model = YOLO('/root/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8n-LSKA-SRFD.yaml')
    # model.load('yolov8n.pt') # loading pretrain weight
    model.train(data='/root/ultralytics-main/ultralytics-main/ultralytics/cfg/datasets/coco128.yaml',
                name='yolov8n-LSKA-SRFD',
                ) 
    
    
    
    