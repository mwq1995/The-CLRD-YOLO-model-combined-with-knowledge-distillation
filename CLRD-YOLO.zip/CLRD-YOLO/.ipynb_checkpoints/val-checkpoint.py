# from ultralytics import YOLO

# if __name__ == '__main__':
#     # Load a model
#     # model = YOLO('yolov8n.pt')  # load an official model
#     model = YOLO('runs/detect/train/weights/best.pt')  # load a custom model
#     model.val()


import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    # model = YOLO('/root/ultralytics-main/ultralytics-main/runs/distill/SRFD-SPPF-LSKA-CSFCN-logical-cwd/weights/best.pt')
    model = YOLO('/root/ultralytics-main/ultralytics-main/runs/detect/yolov8n-LSKA-SRFD/weights/best.pt')
    model.val(data='/root/ultralytics-main/ultralytics-main/ultralytics/cfg/datasets/coco128.yaml',
              split='val',
              imgsz=640,
              batch=16,
              # rect=False,
              # save_json=True, # if you need to cal coco metrice
              project='runs/val1',
              name='yolov8n-LSKA-SRFD',
              )