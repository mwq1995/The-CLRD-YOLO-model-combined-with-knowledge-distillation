from ultralytics import YOLO

# Load a model
model = YOLO("yolov8n.pt")
model = YOLO('runs/detect/yolov6n/weights/best.pt')  # pretrained YOLOv8n model
# results = model("dataset/data/images/test")
# 模型预测，save=True 的时候表示直接保存yolov8的预测结果
# metrics = model.predict(source='dataset/data/a', save=True, hide_labels=True)
metrics = model.predict(source='dataset/data/', save=True)