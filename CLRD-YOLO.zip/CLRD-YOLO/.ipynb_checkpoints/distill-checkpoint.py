import warnings
warnings.filterwarnings('ignore')
import argparse, yaml, copy
from ultralytics.models.yolo.detect.distill import DetectionDistiller

if __name__ == '__main__':
    param_dict = {
        # origin
        'model': '/root/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8-SRFD-SPPF-LSKA-CSFCN.yaml',
        'data':'/root/ultralytics-main/ultralytics-main/ultralytics/cfg/datasets/coco128.yaml',
        'cache': True,
        'project':'runs/distill',
        'name':'SRFD-SPPF-LSKA-CSFCN-feature-constant-BCKD-cwd-0927',
        # 'model': '/root/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8.yaml',
        # 'data':'/root/ultralytics-main/ultralytics-main/ultralytics/cfg/datasets/coco128.yaml',
        # 'cache': True,
        # 'project':'runs/distill',
        # 'name':'v8',
        
        # distill
        'prune_model': False,
        'teacher_weights': '/root/ultralytics-main/ultralytics-main/runs/detect/yolov8数据增强-yolov8s-SRFD-SPPF-LSKA-CSFCN-2024.9.22/weights/best.pt',
        'teacher_cfg': '/root/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8s-SRFD-SPPF-LSKA-CSFCN.yaml',
        'kd_loss_type': 'feature',
        'kd_loss_decay': 'constant',
        
        'logical_loss_type': 'BCKD',
        'logical_loss_ratio': 2.0,
        
        'teacher_kd_layers': '11,14,17,20,21,22',
        'student_kd_layers': '11,14,17,20,21,22',
        'feature_loss_type': 'cwd',
        'feature_loss_ratio': 0.2
    }
    
    model = DetectionDistiller(overrides=param_dict)
    model.distill()